# kOA Digital Ecosystem — Technical Reference

This reference defines ecosystem-level mappings, boundaries and coordination rules. It does not redefine owner contracts.

## Authorities

- **Konnaxion** — civic/public domain state.
- **Orgo** — workflow/work state and durable integration operations.
- **EncyKlopedia** — source discovery/acquisition evidence and immutable handoff.
- **Da’at** — mapping/ACL into Kristal-native contracts.
- **Kristal v6** — referent identity + Kristal State, typed valuations/applicability/roles/actionability, validation/recognition, Reader Policy and derived runtime semantics.
- **UCKK / Univers-Cité** — consumer projection and local Moodle/campus state.
- **kOA-Linux** — platform profiles, admission, release channels and Release Sets.
- **`kristal_runtime`** — local Runtime Pack verification/active-state/rollback receipts.
- **kOA Node Agent** — narrow authorized privileged node-local operations.
- **Koali Spaces** — presentation/Space lifecycle.
- **Interaction Kernel** — selected cross-system Profile/protocol semantics where adopted.
- **SemantiK Architect** — communication realization.
- **SemantiK Runtime Orchestrator** — owner-preserving release sequencing.

## Knowledge baseline

The current knowledge boundary freezes Kristal Standard `6.0.0`, Referent Registry `1.0.0`, EncyKlopedia handoff `1.0.0`, IK build/artifact profiles `2.0.0` and UCKK projection `1.0.0`. Kristal is pinned by its standard manifest and core contract digests. See [`40-integration/knowledge-projection.md`](40-integration/knowledge-projection.md).

## Deployment profile coordination

- [Tandem Konnaxion↔Orgo, VPS Linux + Docker + Capsule Agent](40-integration/tandem-vps-capsule-agent/README.md) — user-selected first target, owner gates and evidence limits (not a GO LIVE approval).

## Start here

- `00-overview/system-at-a-glance.md`
- `10-system/architecture.md`
- `10-system/authority-map.md`
- `10-system/lifecycle.md`
- `10-system/trust-boundaries.md`
- `30-artifacts/release-set-reference.md`
- `30-artifacts/kristal-runtime-state.md`
- `40-integration/contract-map.md`
- `40-integration/knowledge-projection.md`
- `40-integration/interaction-kernel/index.md`
- `40-integration/kristal-v6/index.md`
- `40-integration/koali-spaces/index.md`
- `40-integration/orgo-konnaxion/index.md`
