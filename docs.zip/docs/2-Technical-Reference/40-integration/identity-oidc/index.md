# Common Identity & OIDC Integration Profile

**File:** `docs/2-Technical-Reference/40-integration/identity-oidc/index.md`  
**Status:** Normative (kOA)  
**External normative reference:** OpenID Connect / OAuth specifications as implemented by the selected Identity Provider. This documentation defines the kOA integration profile and does not replace those protocol specifications.

---

## 1) Purpose

Define how human identity can be federated across **Orgo**, **Konnaxion**, and **UCKK-Moodle** without collapsing application boundaries or making any application depend on another for ordinary operation.

The governing design is:

```text
standalone-first
+ optional OIDC federation
+ local authorization
+ no shared passwords
+ no shared application database
```

## 2) Canonical model

```text
                       Identity Provider
                         OIDC / SSO
                              |
                        issuer + subject
                              |
          +-------------------+-------------------+
          |                   |                   |
          v                   v                   v
        Orgo              Konnaxion          UCKK-Moodle
     local account       local account        local account
     local RBAC          local roles          local roles/
                                             capabilities
```

A common identity authenticates a human. It does **not** grant cross-application authority.

## 3) Canonical federated identity key

The portable identity key is:

```text
(issuer, subject)
```

Email, display name, Orgo UUID, Konnaxion user ID, and Moodle user ID are attributes or local identifiers, not ecosystem identity keys.

## 4) Documents

- `principles.md` — hard invariants and ownership boundaries
- `identity-model.md` — Person, FederatedIdentity, LocalAccount, Membership
- `oidc-profile.md` — kOA OIDC profile and login resolution
- `local-authorization.md` — authorization remains application-owned
- `standalone-resilience.md` — outage and break-glass behavior
- `application-profiles.md` — Orgo, Konnaxion, UCKK-Moodle profiles
- `provisioning-lifecycle.md` — linking, JIT provisioning, deactivation
- `security-conformance.md` — security and acceptance gates

## 5) Related ADR

See `../../90-reference/adr/adr-0006-common-identity-oidc.md`.
