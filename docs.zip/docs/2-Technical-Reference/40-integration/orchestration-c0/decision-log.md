# C0 — Decision log

| Decision | Status | Authority | Summary |
|---|---|---|---|
| D-001 | **Approved** | User | Automation after first per-Kristal publication authorization, mandatory qualification on every revision. |
| D-002 | **Coordination policy** | C0 proposal based on ecosystem authority map | Keep each system's native authority; C0 cannot become canonical store. |
| D-003 | **Coordination policy** | C0 proposal | Preserve frozen kOA v6 handoff lane and separately track EncyK v2/Médiathèque and v10 GitHub lane; no implied translation. |
| D-004 | **Test target chosen** | C0 with user-provided Zoology snapshot | Zoology as pilot; no specific release authorization inferred. |
| O-001 | **Open** | User + C2/C3 | Zoology public file list, rights, exclusions, recipient/destination, approval identity and revocation process. |
| O-002 | **Open** | C1 and C2 | Exact accepted independent qualification receipt/profile for v10 surfaces. |
| O-003 | **Open** | C6 bilateral | Mapping EncyK v2 handoff to Médiathèque receiver and legacy v1 compatibility requirement. |
| O-004 | **Open** | C3/C4 | Verified post-release event trigger and exact pinned manifests for cross-repo import. |
| O-005 | **Open** | C5 | Current Integration Pack/Kompiler 0.8 compatibility after representative tests. |

**Change control:** product owner acceptance is required before declaring a proposed owner interface normative or production qualified. Date is the coordination record's date, not a deployment timestamp.

## Additional decisions / open items (2026-10-12)

| Decision | Status | Authority | Summary |
|---|---|---|---|
| D-005 | **User decision (2026-10-12)** | User | Konstellation navigates across Kristals and their concepts; Manager supplies instance inventory; Arketype supplies archetypes/patterns. Integration work remains proposed. |
| O-006 | **Open** | Framework + C0 | Pin exact v10 draft.3.1 source and contract set; current remote HEAD unknown. |
| O-007 | **Open** | C1 + C2 + C3 | Authorize and qualify exact read surface before any public GitHub write. |
| O-008 | **Open** | Manager + Konstellation | Confirm safe local-registry export and implement My Kristals without leaking private metadata. |
