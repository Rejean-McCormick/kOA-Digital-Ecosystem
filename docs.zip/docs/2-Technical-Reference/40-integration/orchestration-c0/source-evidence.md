# C0 — Source evidence and review limits

The following are **exact files inspected in user-provided snapshots** (archive filenames followed by internal paths). Snapshot presence is evidence of source structure and claims, not evidence of an integration running in production. Commit SHAs were not consistently included in snapshots; every workstream must pin commits at execution time.

| Topic | Source path | Observation |
|---|---|---|
| Frozen historical v6 set | `kOA_Digital_Ecosystem.zip:docs/2-Technical-Reference/40-integration/knowledge-projection-contract-set.json` | handoff `encyklopedia.corpus-harvest-handoff/1.0.0`; IK v2; standard v6 pinned |
| EncyK current producer | `Code_snapshot_EncyKlopedia.zip:00_system/contracts/source-evidence-handoff/2.0.0/schema.json` | `encyk.source-evidence-handoff/2.0.0`; target `koa.source-catalog/2.0.0` |
| Médiathèque owner tables | `mediatheque-blank.zip:mediatheque/schemas/sqlite/007_source_authority.sql` | Source/Snapshot/Representation/Binding storage, not proof of handoff 2.0 acceptance |
| IK optional knowledge admission | `interaction_kernel.zip:interaction_kernel/contracts/profiles/kristal/kristal.build.request/2.0.0/payload.schema.json` | portable v6 knowledge profile, not implicit GitHub v10 step |
| Framework GitHub read layer | `Code_snapshot_Kristal-Framework(6).zip:profiles/github/examples/github-read-surface.example.json` | `kristal.github-read-surface/1.0` |
| Framework sync layer | `Code_snapshot_Kristal-Framework(6).zip:profiles/github/examples/github-sync-manifest.example.json` | `kristal.github-sync-manifest/1.0` |
| Framework collection discovery | `Code_snapshot_Kristal-Framework(6).zip:profiles/github/examples/github-collection-index.example.json` | `kristal.github-collection-index/1.0` |
| Local Zoology | `Kristal-Zoology.zip:Kristal-Zoology/kristal.workspace.json` and `.kristal/v9/state-snapshot.json` | v6 payload, v9 identity, v10 hosting target; portable AI disabled in source ZIP |
| Public Zoology candidate | `Code_snapshot_kristal-public.zip:kristals/zoology/state/state-snapshot.json` | public state snapshot exists; root `state/state-snapshot.json` is a separate genesis fixture |
| Light catalogue and workflow | `Code_snapshot_Konstellation-Light.zip:light/site/data/catalog.json` and `.github/workflows/konstellation-light-pages.yml` | single demo `demo-v9-small`; manual workflow, no automatic external repo fetching |
| Kompiler consumer | `Code_snapshot_Kompiler(2).zip:docs/03-runtime/github-collection-reader.md` | GitHub read-only adapter described; version `0.8.0-alpha.1` |
| Integration Pack | `Code_snapshot_Kristal-Integration-Pack.zip:docs/QUALIFICATION.md` | historical 0.7 bridge target; local tests not updated-system verification |

**Not checked here:** independent Zoology domain truth certification, real Médiathèque acceptance, production release pipeline with per-Kristal approval, cross-repository auth triggers, actual public-site UI acceptance, or compatibility of unpinned future commits.
