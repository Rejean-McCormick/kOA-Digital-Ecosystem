# Readiness and qualification ledger (snapshot-limited)

**Review date:** 2026-10-12. **Status vocabulary:** `OBSERVED_SNAPSHOT`, `DOCUMENTED`, `USER_DECIDED`, `PROPOSED`, `BLOCKED`, `UNKNOWN`; these are not interchangeable with operational publication states.

| System | Snapshot-supported observation | Current gate |
|---|---|---|
| Framework | `10.0.0-draft.3.1`, local TCK/validator passed in prior audit | Exact approved remote contract-set pin not confirmed |
| Authoring Kit | 3.2.4; Arketype tool copy byte-identical to Kit 3.2.4 in previous audit | Cross-version local migration and fleet readiness pending |
| Manager | `0.1.0-alpha.11` documented; supplied snapshot lacks importable `kristal_manager/` package | `M-01` BLOCKED until a complete checkout is available |
| Bootstrap | 1.1.0-alpha.11; documented `doctor/plan/apply` and candidate C2 gates | Pin and managed-file fingerprint drift need review |
| `kristal-public` | Zoology state exists, but `kristals/index.json` and required sync/AI surfaces absent in ZIP | C3 scan BLOCKED; no qualified collection claimed |
| `kristal-private` | Provided snapshot contains no repository file | UNKNOWN; not evidence of remote absence |
| Local fleet | 126 distinct `state_ref` and 212 indexed artifacts in ZIP; declared v10 hosting target | No E2E verification; older embedded kits need staged checks |
| Arketype | 19 candidate types, neutral templates and standalone desktop launcher | Planned GitHub software repo integration; no hosting authority |
| Kollection | Historical registry and UCKK stubs, legacy report references 125 packages | Reconciliation/crosswalk pending; not a v10 source of truth |
| Konstellation | `/api/kristals`, `Explorer.svelte` selector, v10 adapter; 7 isolated adapter tests passed | Fleet *My Kristals* and all-v9-concept traversal not yet established |
| Kompiler / Integration Pack | Read-only interface documented; historical/local C5 test evidence | Qualified v10 published input/context-pack round trip pending |
| Konstellation Light | Pinned importer and C4 static-reader workflow | Public rebuild remains gated on exact approved release |
| EncyK → Médiathèque | v2 producer and source catalogue model documented | Real consumer receipts/idempotency remain unverified |

## What C0 may safely say now

**Architectural compatibility is described; exact cross-repository deployed alignment is not yet established.** C0 must not promote a row to `QUALIFIED` because a schema exists, a GitHub file was pushed or an unrelated local test passed. Evidence must identify owner, exact source revision, test command/outcome, corresponding receiver behavior, receipts and authorized visibility.

## Current priority order

P0: confirm F-01 baseline, obtain M-01 complete runtime, align C1/C2, preserve fail-closed C3, classify private target and local instances. P1: build one synthetic/staging fixture through Kit → Manager → C3 and read it in Konstellation; separately introduce the local fleet viewer. P2: Arketype/GitHub software integration and read-only compatibility diagnostics. P3: migrate/retire Kollection legacy functions only after crosswalk.
