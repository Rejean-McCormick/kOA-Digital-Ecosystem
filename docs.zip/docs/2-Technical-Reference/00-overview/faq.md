# FAQ

## Who owns active Runtime Pack state in kOA-Linux?
`kristal_runtime`. It owns verification/compatibility records, active Runtime Pack state, activation/rollback receipts and runtime health.

## What does kOA Node Agent do?
It performs narrow authorized node-local lifecycle/activation/recovery transitions when the active profile/contract requires host privilege. It does not become the owner of Kristal semantics or release authority.

## What does Release Set do?
It binds compatible versions across the independent kOA-Linux release channels. It does not replace Runtime Pack active state.

## Is Interaction Kernel already universal inside kOA-Linux?
No. It is the target cross-system protocol/Profile layer. kOA-Linux has its own canonical internal/component contracts until explicit adoption/mapping is published.

## Is Koali Space activation a knowledge activation?
No. Koali Space activation is presentation/application composition.
