# kOA Layer Model

**Status:** conceptual orientation / classification
**Normative for kOA:** NO

## Purpose

This documentation defines the current **conceptual layer model** for kOA. It is the consolidated navigation/classification view for understanding how kOA turns meaning into collective capacity.

```text
meaning → knowledge → decision → action → memory → future capacity
```

It does not replace the technical architecture, owner contracts or authority maps.

## Layer stack

```text
0.  Separation of functions
1.  Orientation / mandate
2.  Semantics / meaning
3.  Provenance / ingestion
4.  Structured knowledge
5.  Validation / canon
6.  Deliberation
7.  Decision / legitimacy
8.  Execution
9.  Memory / learning
10. Resilience / autonomy
11. Learning / interface
12. Narrative / adoption
13. Deployment / translation
```

## Relationship to technical architecture

The technical documentation answers:

```text
How does the kOA Digital Ecosystem work, who owns what, and under which contract?
```

The Layer Model answers:

```text
Which conceptual functions must exist for kOA to turn meaning into collective capacity?
```

Classification never overrides ownership, contract version, qualification or activation state.

## Start here

- [`LAYER_MODEL.md`](LAYER_MODEL.md)
- [`LAYER_INDEX.md`](LAYER_INDEX.md)
- [`layers/`](layers/)

Use [`LAYER_TEMPLATE.md`](LAYER_TEMPLATE.md) when adding or revising a layer.

## Non-goals

This model does not redefine Kristal contracts, runtime schemas, platform profiles, product state, trust policy, integration contracts or release evidence.
