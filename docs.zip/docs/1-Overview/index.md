# kOA Digital Ecosystem

kOA is a system of independently owned systems connected through explicit contracts.

## System map

```text
                         ┌──────────────────┐
                         │   Konnaxion      │
                         │ civic decisions  │
                         └────────┬─────────┘
                                  │ IK decision profile
                                  ▼
                         ┌──────────────────┐
                         │      Orgo        │
                         │ governed work    │
                         └────────┬─────────┘
                                  │ immutable source exports when needed
                                  │
Sources/providers                ▼
      │                 ┌──────────────────┐
      ▼                 │      Da’at       │
┌──────────────┐        │ mapping / ACL    │
│ EncyKlopedia │───────▶└────────┬─────────┘
│ acquisition  │ handoff          │ Kristal-native contracts
└──────────────┘                  ▼
                         ┌──────────────────┐
                         │     Kristal      │
                         │ epistemic canon  │
                         └───────┬─────┬────┘
                                 │     │
                      Runtime Pack     │ projection artifact
                                 │     ▼
                                 │  ┌────────────────────┐
                                 │  │ UCKK / Univers-Cité│
                                 │  │ Moodle/projections │
                                 │  └────────────────────┘
                                 ▼
                         ┌──────────────────┐
                         │    kOA-Linux     │
                         │ release/admission│
                         └────────┬─────────┘
                                  ▼
                         kristal_runtime
                                  │
                         kOA Node Agent
                         (only when privilege is required)

Koali Spaces may compose admitted application surfaces above these systems.
It owns presentation state only.
```

A kOA-Linux profile may activate only a subset of ecosystem systems. **Platform composition is not ecosystem membership.**

## Owners

- **Konnaxion** — civic/public state and finalized DecisionRecords.
- **Orgo** — workflow/work state and durable external operations.
- **EncyKlopedia** — source discovery/acquisition, provider resolution and immutable evidence handoff.
- **Da’at** — mapping/ACL into Kristal-native contracts.
- **Kristal** — referent semantics, epistemic artifacts, validation/recognition and Runtime Pack semantics.
- **UCKK / Univers-Cité** — consumer projection choices, Moodle/campus state and institutional learning decisions.
- **kOA-Linux** — platform profiles, admission, release channels and Release Set coordination.
- **`kristal_runtime`** — Runtime Pack verification, active-state and rollback receipts.
- **kOA Node Agent** — narrow privileged host transitions.
- **Koali Spaces** — shell/presentation composition and Space lifecycle.
- **Interaction Kernel** — explicit versioned protocol/Profile layer where adopted.
- **SemantiK Architect** — semantic-to-human communication realization.
- **SemantiK Runtime Orchestrator** — owner-preserving RuntimeSet release coordination.

## Key non-confusions

```text
acquisition evidence          ≠ validated epistemic assertion
external identifier          ≠ authority
consumer projection          ≠ Kristal source of truth
Moodle materialization       ≠ epistemic canon
Release Set compatible       ≠ Runtime Pack active
Runtime Pack active          ≠ Koali Space active
IK profile                   ≠ universal ecosystem transport
platform composition         ≠ ecosystem membership
```

## Control views

[Authority map](../2-Technical-Reference/10-system/authority-map.md) · [Contract map](../2-Technical-Reference/40-integration/contract-map.md) · [Maturity map](../status/current.md) · [Layer Model](../3-Layer-Model/README.md)

**Additional mapped applications:** [Skope & Ékole](Components-Skope-and-Ekole.md) (prototype/consumer roles; no new authority transfer).

## Proposed Skope / Ékole flow (not qualified)

```text
Wikidata / local copy
    │
    ▼
Skope (local, offline-capable)
    └─ recipe + reviewed working snapshot [NO CANON]
                    │
                    ▼ proposed owner-governed handoff
     EncyKlopedia / Médiathèque source custody
                    │
                    ▼
            Da’at / Authoring Kit
                    │ explicit validation & compilation
                    ▼
            Kristal epistemic canon
                    │ qualified consumer projection
                    ▼
             Ékole / UCKK
          ├─ learner/teacher portal
          └─ candidate Moodle plan (no live writes)
```

All middle transitions shown as proposed remain **unqualified** in the supplied snapshots. See the [Skope/Ékole contract supplement](../2-Technical-Reference/40-integration/skope-ekole/index.md).
